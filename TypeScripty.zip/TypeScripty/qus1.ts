const Rate=10;
if(true){
    const Rate =8;
    console.log(Rate);
}
console.log(Rate);
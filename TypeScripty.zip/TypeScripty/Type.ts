let num1;
const num2 = 10;

const obj1 = {
    name : "joatmon"
};
console.log(obj1.name)

obj1.name = "Chandler";

console.log(obj1.name);